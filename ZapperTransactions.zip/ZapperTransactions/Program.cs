﻿using System;
using System.IO;
using System.Linq;

namespace ZapperTransactions
{
    class Program
    {
        public static bool IsFeatureEnabled(string settings, int setting)
        {
            if (settings.Length != 8 || setting < 1 || setting > 8)
            {
                throw new ArgumentException("Invalid settings string or setting index.");
            }

            return settings[setting - 1] == '1';
        }

        public static void WriteUserSettings(string filename, string settings)
        {
            if (settings.Length != 8 || !settings.All(c => c == '0' || c == '1'))
            {
                throw new ArgumentException("Settings must be a binary string of length 8.");
            }

            byte byteValue = Convert.ToByte(settings, 2);
            File.WriteAllBytes(filename, new[] { byteValue });
        }

        public static string ReadUserSettings(string filename)
        {
            if (!File.Exists(filename))
            {
                return "00000000"; // Return default settings if file does not exist
            }

            byte byteValue = File.ReadAllBytes(filename)[0];
            return Convert.ToString(byteValue, 2).PadLeft(8, '0');
        }

        public static void Main(string[] args)
        {
            // Example usage
            WriteUserSettings("user_settings.bin", "11010010");
            string settings = ReadUserSettings("user_settings.bin");
            Console.WriteLine(settings);  // Output: '11010010'

            // Test cases
            Console.WriteLine(IsFeatureEnabled(settings, 7));  // Output: False
            Console.WriteLine(IsFeatureEnabled(settings, 4));  // Output: True
        }
    }
}
