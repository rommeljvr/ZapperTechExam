-- Create the database
CREATE DATABASE ZapperDB;
GO

-- Use the new database
USE ZapperDB;
GO

-- Create Zapper schema
CREATE SCHEMA Zapper;
GO

-- Create Users table in Zapper schema
CREATE TABLE Zapper.Users (
    UserID INT PRIMARY KEY IDENTITY(1,1),
    UserName NVARCHAR(255) NOT NULL,
    Email NVARCHAR(255) NOT NULL UNIQUE,
    CreatedAt DATETIME DEFAULT GETDATE()
);
GO

-- Create Merchants table in Zapper schema
CREATE TABLE Zapper.Merchants (
    MerchantID INT PRIMARY KEY IDENTITY(1,1),
    MerchantName NVARCHAR(255) NOT NULL,
    ContactInfo NVARCHAR(255),
    CreatedAt DATETIME DEFAULT GETDATE()
);
GO

-- Create Transaction_Status table in Zapper schema
CREATE TABLE Zapper.Transaction_Status (
    StatusID INT PRIMARY KEY IDENTITY(1,1),
    StatusName NVARCHAR(50) NOT NULL
);
GO

-- Create Transactions table in Zapper schema
CREATE TABLE Zapper.Transactions (
    TransactionID INT PRIMARY KEY IDENTITY(1,1),
    UserID INT,
    MerchantID INT,
    TransactionAmount DECIMAL(10, 2) NOT NULL,
    TransactionDate DATETIME DEFAULT GETDATE(),
    StatusID INT,
    FOREIGN KEY (UserID) REFERENCES Zapper.Users(UserID),
    FOREIGN KEY (MerchantID) REFERENCES Zapper.Merchants(MerchantID),
    FOREIGN KEY (StatusID) REFERENCES Zapper.Transaction_Status(StatusID)
);
GO
